export interface Transactions {
    sum: number;
    valute: string;
    emblem: string;
    title: string;
    subtitle: string;
}